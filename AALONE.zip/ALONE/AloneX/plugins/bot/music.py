from pyrogram import filters
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from AloneX import app
from config import BOT_USERNAME
#from AloneX.utils.errors import capture_err
import httpx 
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup

start_txt = """
**
┌┬─────────────────⦿
│├─────────────────╮
│├ 𝗧ɢ 𝗡ᴀᴍᴇ - [RAJA](https://t.me/rajaraj909)
│├ 𝗙ᴜʟʟ 𝗜ɴғᴏ - [𝐂ʟɪᴄᴋ 𝐇ᴇʀᴇ](https://t.me/djdjdjznsnsn)
│├─────────────────╯
├┼─────────────────⦿
│├─────────────────╮
│├ 𝗢ᴡɴᴇʀ│ [RAJA BHAI](https://t.me/RAJARAJ909)
│├─────────────────╯
└┴─────────────────⦿
**
"""




@app.on_message(filters.command("repo"))
async def start(_, msg):
    buttons = [
        [ 
          InlineKeyboardButton("ONWER", url="https://t.me/RAJARAJ909")
        ],
        [
          InlineKeyboardButton("ALL REPO", url="https://te.legra.ph/file/29f784eb49d230ab62e9e.mp4"),
          InlineKeyboardButton("REPO", url="https://files.catbox.moe/k3q4k0.jpg"),
          ],
        [
          InlineKeyboardButton("RAJA BHAI KA NETWORK", url="https://t.me/djdjdjznsnsn"),
        ],
        [
          InlineKeyboardButton("OFFICIAL BOT", url="https://t.me/Kusummusic7_bot"),
        ]
    ]
    
    reply_markup = InlineKeyboardMarkup(buttons)
    
    await msg.reply_photo(
        photo="https://files.catbox.moe/ig2j8u.mp4",
        caption=start_txt,
        reply_markup=reply_markup
    )